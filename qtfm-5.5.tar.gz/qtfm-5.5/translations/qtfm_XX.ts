<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en" sourcelanguage="en">
<context>
    <name>MainWindow</name>
    <message>
        <source>New folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Middle-click things to open tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Middle-click tabs to close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move the current file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy the current file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste the file here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Go up one directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Go back one directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Go to home directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Detail view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle detailed list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icon view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle icon view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hidden files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle hidden files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add this folder to bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add separator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add separator to bookmarks list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove this bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change bookmark icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wrap bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete selected file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit custom actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configure shortcuts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit keybindings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit filetype</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set default program for opening selected filetype</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open virtual terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open the file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run this program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quit qtFM and stop the daemon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close qtFM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show thumbs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View thumbnails in icon view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View properties of selected items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lock layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Focus address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicate shortcuts detected:&lt;p&gt;%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Navigate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default terminal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read only...cannot create folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read only...cannot create file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to confirm all delete operations?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Careful</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete &lt;p&gt;&lt;b&gt;&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not delete some items...do you have the right permissions?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No paste for you!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File no longer exists!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Existing folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copying...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moving...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste failed...do you have write permissions?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Too big!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There is not enough space on the destination drive!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unlock layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configure filetype</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filetype:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open with:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error - Custom action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output - Custom action</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>customActionsDialog</name>
    <message>
        <source>Filetype</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Usage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use &apos;folder&apos; to match all folders.&lt;br&gt;Use a folder name to match a specific folder.&lt;br&gt;Set text to &apos;Open&apos; to override xdg default.&lt;p&gt;%f - selected files&lt;br&gt;%F - selected files with full path&lt;br&gt;%n - current filename&lt;/p&gt;&lt;p&gt;[] - tick checkbox to monitor output and errors.&lt;/p&gt;&lt;p&gt;See &lt;a href=&apos;http://www.qtfm.org/home/readme&apos;&gt;readme&lt;/a&gt; for more help.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extract here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Term here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compress</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>icondlg</name>
    <message>
        <source>Select icon</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>myModel</name>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Owner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date Modified</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>myProgressDialog</name>
    <message>
        <source>Initializing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;Transfer rate: %2 MB/s&lt;br&gt;Time remaining: %3&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>propertiesDialog</name>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contains:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filetype:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modified:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;%1 files, %2 folders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;%1 folders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;%1 files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Owner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Numeric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 Files, %2 folders</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
